!function($, window, undefined) {
	window.Constants = window.Constants ||{};
	Constants.root = '/soa-rest';
	
	
}(jQuery, window);