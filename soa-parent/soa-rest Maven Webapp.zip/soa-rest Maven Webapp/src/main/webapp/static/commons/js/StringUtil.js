!function($, window, undefined) {
	window.StringUtil = window.StringUtil ||{};
	StringUtil.isNotBlank = function(str){
		return (str!=null && str!='');
	};
	
	
}(jQuery, window);