angular.module('controllers',[])

.controller('index',function($scope,$routeParams){
	
})

.controller('user.id',function($scope,$routeParams){
		alert($routeParams.id);
})

.controller('form',function($scope){
	
})
;